# PCH-1000-JIG-PCB
PCB for JIG on PCH-1000/PDEL-1000 PSVITA

Logic was tested (board itself still untested).

![image](https://user-images.githubusercontent.com/203427/224272758-930ef81a-a32f-41a9-afde-b1d8dcfc2766.png)
![image](https://user-images.githubusercontent.com/203427/224272828-b04cba04-a9a8-4f40-96c6-87245885e82e.png)

